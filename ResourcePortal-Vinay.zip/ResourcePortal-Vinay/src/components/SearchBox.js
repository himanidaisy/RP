import React, { useState } from 'react';
import {StyleSheet, Text, TextInput, View} from 'react-native';

import Icon from 'react-native-vector-icons/Ionicons';
import {COLORS} from '../constants/theme';

const SearchBox = (props) => {
  const handleChangeValue = (value) => {
    props.setSearchValue(value)
  }
  return (
    <View style={styles.TextInputView}>
      <TextInput placeholder="Search" style={styles.TextInput}
      onChangeText={handleChangeValue}
      value={props.search}

      />

      <Icon name="search-outline" size={20} style={styles.IconStyle} />
    </View>
  );
};

const styles = StyleSheet.create({
  TextInputView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: '5%',
    padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  TextInput: {
    marginStart: '3%',
    fontSize: 15,
    flex: 1,
  },
  IconStyle: {
    padding: '3%',
    margin: '1%',
  },
});
export default SearchBox;