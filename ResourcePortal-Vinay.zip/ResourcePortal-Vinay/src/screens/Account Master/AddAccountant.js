import React from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  ToastAndroid,
  TextInput,
  StyleSheet
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,FONTS} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AddAccountant = ({navigation}) => {
  const phoneRegExp = /^(\+91)?(-)?\s*?(91)?\s*?(\d{3})-?\s*?(\d{3})-?\s*?(\d{4})$/
  const loginValidationSchema = yup.object().shape({
        name: yup.string().required('These field is Required'),
        phone: yup.string().matches(phoneRegExp,'Please enter a vald number').required('These field is Required'),
        email: yup.string().email('Email is not valid').required('These field is Required'),
  })
  //post
  const postUser = async values => {
    console.log(values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL+"/account",
        values,
        requestOptions,
      );

      console.log('check-----------',data);

    if (data.message) {
        ToastAndroid.showWithGravity(
          'Accounts created successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
        navigation.goBack();
      }
    } catch (err) {
      ToastAndroid.showWithGravity(
        'Accounts not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    postUser(values);
  };
  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Accountant" />
      <View style={styles.container}>
        <Formik
          validationSchema={loginValidationSchema}
          initialValues={{name: '', phone: '', email: ''}}
          onSubmit={handleSubmit}>
          {({handleChange, handleBlur, handleSubmit, errors, touched}) => (
            <>
              <View style={styles.textInputView}>
                <TextInput
                  placeholder="Name*"
                  style={styles.textInput}
                  onChangeText={handleChange('name')}
                  onBlur={handleBlur('name')}
                />
              </View>
              {errors.name && touched.name && (
                <Text style={styles.errorStyle}>{errors.name}</Text>
              )}
              <View style={styles.textInputView}>
                <View style={styles.innerBtn}>
                  <FontAwesome
                    name="phone"
                    size={25}
                    style={styles.iconStyle}
                  />
                </View>
                <TextInput
                  placeholder="Phone Number*"
                  style={styles.textInput}
                  onChangeText={handleChange('phone')}
                  onBlur={handleBlur('phone')}
                />
              </View>
              {errors.phone && touched.phone && (
                <Text style={styles.errorStyle}>{errors.phone}</Text>
              )}
              <View style={styles.textInputView}>
                <View style={styles.innerBtn}>
                  <MaterialCommunityIcons
                    name="email-outline"
                    size={20}
                    style={styles.iconStyle}
                  />
                </View>
                <TextInput
                  placeholder="Email Id*"
                  style={styles.textInput}
                  onChangeText={handleChange('email')}
                  onBlur={handleBlur('email')}
                />
              </View>
              {errors.email && touched.email && (
                <Text style={styles.errorStyle}>{errors.email}</Text>
              )}
              <TouchableOpacity
                style={styles.buttonStyle}
                onPress={()=> handleSubmit()}
                >
                <Text style={styles.textStyle}>Submit</Text>
              </TouchableOpacity>
            </>
          )}
        </Formik>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  margin: 15,
  borderRadius: 10,
  padding:4,
  backgroundColor: COLORS.pureWhite,
  },
  innerBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    padding:2,
    backgroundColor: COLORS.lightBlue,
  },
  textInput: {
    marginStart: '3%',
    fontSize: 15,
    flex: 1,
  },
  iconStyle: {
    padding: '3%',
    margin: '1%',
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  errorStyle:{
    ...FONTS.appFontSemiBold,color:COLORS.red,textAlign:'center'
  }
})

export default AddAccountant;
