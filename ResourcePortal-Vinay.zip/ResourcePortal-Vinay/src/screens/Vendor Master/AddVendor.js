import React, {useState,useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {FONTS,COLORS} from '../../constants/theme';
import Icon from 'react-native-vector-icons/FontAwesome';
import EmailIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Picker } from '@react-native-picker/picker';

const AddVendor = () => {
  const [company, setCompany] = useState('');
  // const [name, setName] = useState('');
   const [person, setPerson] = useState('');
  const [address, setAddress] = useState('');
  const [number, setNumber] = useState('');
  const [email, setEmail] = useState('');
  const [gstl, setGstl] = useState('');
  const [gst, setGst] = useState('');
  const [pan, setPan] = useState('');
  const [agreement, setAgreement] = useState('');
  const [panl, setPanl] = useState('');
  const [newData, setNewData] = useState([]);
  
 
  useEffect(() => {
    getResource();
    
  }, []);
//get
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
        'http://newresourcing.nimapinfotech.com/api/vendor',
        requestOptions,
      );

      // console.log(data.data.data.vendors);

      setNewData(data.data.data.vendors);
    } catch (error) {
      console.log(error);

    }
  };
  const postUser = async () => {
    const store = {
      "client_name": "",
       "contact_person":person ,
       "company_address": address,
       "contact_number": number,
       "contact_email": email,
       "gst_link": gstl,
       "gst": gst,
       "pan": pan,
       "agreement_link": agreement,
       "pan_link": panl,
       "company_name" :company
     }
    
  try {
    const token = await AsyncStorage.getItem('token');

    const requestOptions = {
      
      method: 'POST',
      Accept: 'application/json',
      'Content-Type': 'application/json',
      headers: {Authorization: 'Bearer ' + token},
    };

    const {data} = await axios.post(
      'http://newresourcing.nimapinfotech.com/api/vendor',store,
      
      requestOptions,
      
    );
    console.log('check-------------->', data)

  } catch (err) {
    console.log("Error--------------------------->",err);
  }
};
const clientsOptions = newData.filter(t=>t.company_name !== null)

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Vendor" />
      <ScrollView>
      <View style={styles.textInputView}>
        <Picker
        selectedValue={company}
        style={styles.textInput}
        onValueChange={(value)=> setCompany (value)}
        mode='dropdown'>
          {clientsOptions.map((item,index)=>(
             <Picker.Item key={item.company_name.id}  label={item.company_name} value={item.company_name.id} />
          ))
          }
      </Picker>
    </View>

        <View style={styles.textInputView}>
          <TextInput
            placeholder="Contact Person*"
            style={styles.textInput}
            value={person}
            onChangeText={(data)=> setPerson(data)}

          />
        </View>

        <View style={styles.textInputView}>
          <View style={styles.phoneIcon}>
            <Icon name="phone" size={25} style={styles.iconStyle} />
          </View>
          <TextInput
            placeholder="Mobile*"
            style={styles.textInput}
            value={number}
            onChangeText={(data)=> setNumber(data)}

          />
        </View>

        <View style={styles.textInputView}>
          <View style={styles.phoneIcon}>
            <EmailIcon
              name="email-outline"
              size={20}
              style={styles.iconStyle}
            />
          </View>
          <TextInput
            placeholder="Email Id*"
            style={styles.textInput}
            value={email}
            onChangeText={(data)=> setEmail(data)}

          />
        </View>

        <View style={styles.textInputView}>
          <TextInput
            placeholder="Company Address"
            style={styles.textInput}
            value={address}
            onChangeText={(data)=> setAddress(data)}

          />
        
        </View>

        <View style={styles.textInputView}>
          <TextInput
            placeholder="PAN Number"
            style={styles.textInput}
            value={pan}
            onChangeText={(data)=> setPan(data)}

          />
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Upload PAN"
            style={styles.textInput}
            value={panl}
            onChangeText={(data)=> setPanl(data)}

          />
        </View>
        
        <View style={styles.textInputView}>
          <TextInput
            placeholder="GST Number"
            style={styles.textInput}
            value={gst}
            onChangeText={(data)=> setGst(data)}

          />
        
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Upload GST"
            style={styles.textInput}
            value={gstl}
            onChangeText={(data)=> setGstl(data)}

          />
        
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Agreement Attachment"
            style={styles.textInput}
            value={agreement}
            onChangeText={(data)=>setAgreement (data)}

          />
        
        </View>

      
        <TouchableOpacity style={styles.submitBtn}
                onPress={()=> postUser()}>
          <Text style={styles.submitText}>Submit</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles=StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  submitBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginTop: 20,
    marginHorizontal: 22,
    padding: '4%',
    margin: '10%',
    backgroundColor: COLORS.blue,
  },
  submitText: {
    color: COLORS.white,
    ...FONTS.appFontSemiBold,
  },
  btnTextClient: {
    ...FONTS.appFontSemiBold,
  },
  textInputView: {
    flexDirection: 'row',
    margin: 15,
    marginTop: '5%',
    padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  phoneIcon: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    padding:2,
    backgroundColor: COLORS.lightBlue,
  },
  iconStyle: {
    padding: '3%',
    margin: '1%',
  },
  uploadBtnClient: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    margin: '5%',
    padding: 5,
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  errorText: {
    color: COLORS.red,
textAlign:'center'
  },
  textInput: {
    marginStart: '3%',
    fontSize: 15,
    flex: 1,
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
  },
})
export default AddVendor;