import React, {useState,useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  StyleSheet
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,FONTS,GLOBALSTYLES} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker'
import axios from 'axios';
import DatePicker from 'react-native-datepicker';
const AddClientAgreement = ({navigation}) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [newData, setNewData] = useState([]);
  const [id, setId] = useState();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  // const [drive, setDrive] = useState('');
  const [upload, setUpload] = useState('');
 
  useEffect(() => {
    getResource();
    
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
       'http://newresourcing.nimapinfotech.com/api/client-agreement',
        requestOptions,
      );

    //  console.log(data.data.data.clientAgreements);

      setNewData(data.data.data.clientAgreements);
    } catch (error) {
      console.log(error);

    }
  };

  const postUser = async () => {
    const store ={
      "client_id" : id,
      "start_date" :startDate,
      "end_date" :endDate ,
      "title" :title,
      "description" :description,
      "pdf_file" :upload,

    }

    // console.log('checkv--------', store);
    try {
      const token = await AsyncStorage.getItem('token');
  
      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
  
      const {data} = await axios.post(
       'http://newresourcing.nimapinfotech.com/api/client-agreement',
        store,
        requestOptions,
      );
  
      // console.log('valuecheck------------->',data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Client order added successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );

        navigation.goBack();
      }
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Client not Added',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
    
  };
 
  const clientsOptions = newData.filter(t=>t.client !== null)

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Client Agreement" />
      <View style={styles.container}>
      <View style={styles.textInputView}>
        <Picker
        selectedValue={id}
        style={styles.textInput}
        
        onValueChange={(value)=> setId (value)}>
          <Picker.Item label=" Client Name" value="" /> 
          {clientsOptions.map((item,index)=>(
             <Picker.Item key={item.client.id}  label={item.client.client_name} value={item.client.id} />
          ))
          }
      </Picker>
    </View>
       
    <View style={styles.textInputDate}>
        <DatePicker
          style={styles.textInput}
          date={startDate} 
          value={startDate}
          mode="date" 
          placeholder="Start Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"    
          showIcon={false}
      customStyles={{dateInput:{borderWidth:0}}}
          onDateChange={startDate => {
            setStartDate(startDate);
          }}
        />
        <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />

      </View>
     
      <View style={styles.textInputDate}>
        <DatePicker
          style={styles.textInput}
          date={endDate}
          value={endDate}
          mode="date" 
          placeholder="End Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          showIcon={false}
          customStyles={{dateInput:{borderWidth:0}}}

          onDateChange={endDate => {
            setEndDate(endDate);
          }}
        />
        <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />
  </View>
       
        <View style={styles.textInputView}>

          <TextInput placeholder="Title" style={styles.textInput} 
          value={title}
          onChangeText={(data)=> setTitle(data)}
          />
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Description"
            style={styles.textInput}
            value={description}
            onChangeText={(data)=> setDescription(data)}
          />
        </View>
        {/* <View style={GLOBALSTYLES.TextInputViewAcc}>
          <TextInput
            placeholder="Drive Link"
            style={GLOBALSTYLES.TextInputAcc}
            value={drive}
            onChangeText={(data)=> setDrive(data)}
          />
        </View> */}
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Upload"
            style={styles.textInput}
            value={upload}
            onChangeText={(data)=> setUpload(data)}
          />
        </View>
        
        <TouchableOpacity style={styles.buttonStyle}
        onPress={()=> postUser()}>
        <Text style={styles.textStyle}>Submit</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView:{
  flexDirection: 'row',
  justifyContent: 'space-between',
  margin: 15,
  borderRadius: 10,
  padding:4,
  backgroundColor: COLORS.pureWhite
  },
  textInputDate:{
  flexDirection: 'row',
  justifyContent: 'space-between',
  margin: 15,
  borderRadius: 10,
  padding:8,
  backgroundColor: COLORS.pureWhite
  },
  textInput: {
    flex: 1,
    marginStart: '3%',
    fontSize: 15,
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  iconStyle:{
    margin:10
  }
})
export default AddClientAgreement;