import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  StyleSheet
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,FONTS} from '../../constants/theme';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AddTechnology = ({navigation}) => {

  const loginValidationSchema = yup.object().shape({
    technology: yup.string().required('Please fill out this filed'),
    url: yup.string().required('Please fill out this filed'),
  });
  //post
  const postUser = async values => {
    // console.log('check=--------',values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
       URL.BASE_URL+"/technology",
        values,
        requestOptions,
      );
      // console.log(data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Technology Added Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();

    } catch (err) {
      ToastAndroid.showWithGravity(
        'technology not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    postUser(values);
  };


  return (
    <SafeAreaView style={styles.mainContainerEx}>
      <CustomNavigationBar back={true} headername="Add Technology" />
      <ScrollView>
        <View style={styles.container}>
          <Formik
            validationSchema={loginValidationSchema}
            initialValues={{technology: '', url: ''}}
            onSubmit={handleSubmit}>
            {({handleChange, handleBlur, handleSubmit, errors, touched}) => (
              <>
                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="Name*"
                    style={styles.textInput}
                    onChangeText={handleChange('technology')}
                    onBlur={handleBlur('technology')}
                  />
                </View>
                {errors.technology && touched.technology && (
                  <Text style={styles.errorStyle}>
                    {errors.technology}
                  </Text>
                )}

                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="URL"
                    style={styles.textInput}
                    onChangeText={handleChange('url')}
                    onBlur={handleBlur('url')}
                  />
                </View>
                {errors.url && touched.url && (
                  <Text style={styles.errorStyle}>{errors.url}</Text>
                )}
                <TouchableOpacity
                  style={styles.submitBtn}
                  onPress={handleSubmit}>
                  <Text style={styles.submitText}>Submit</Text>
                </TouchableOpacity>
              </>
            )}
          </Formik>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  margin: 15,
  borderRadius: 10,
  padding:4,
  backgroundColor: COLORS.pureWhite,
  },
  innerBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    padding:2,
    backgroundColor: COLORS.lightBlue,
  },
  textInput: {
    marginStart: '3%',
    fontSize: 15,
    flex: 1,
  },
  iconStyle: {
    padding: '3%',
    margin: '1%',
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  errorStyle:{
    ...FONTS.appFontSemiBold,color:COLORS.red,textAlign:'center'
  },
  submitBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginTop: 20,
    marginHorizontal: 22,
    padding: '4%',
    backgroundColor: COLORS.blue,
  },
  submitText: {
    color: COLORS.white,
    ...FONTS.appFontSemiBold,
  },
})
export default AddTechnology;