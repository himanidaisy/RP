import React, {useState,useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  StyleSheet
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,FONTS} from '../../constants/theme';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';

const EditTechnology = ({route,navigation}) => {
    const [data, setData] = useState({});
    const [name, setName] = useState('');
 useEffect(() => {
      setData(route.params.newData);
      setName(route.params.newData);
    }, []);

  const loginValidationSchema = yup.object().shape({
    technology: yup.string().required('Please fill out this filed'),
    url: yup.string().required('Please fill out this filed'),
  });
//put
const putUser = async values => {
    console.log(values);
    const id = route.params.newData.id;
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        `http://newresourcing.nimapinfotech.com/api/technology/${id}`,
        values,
        requestOptions,
      );
       console.log(data);
      setData(route.params.newData);
      setName(route.params.newData);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Technology edited successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
        navigation.goBack()

      }
    } catch (err) {
      console.log(err.response)
      ToastAndroid.showWithGravity(
        'Technology not edited',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
    
  };
  const handleSubmit = values => {
    putUser(values);
    // console.log('values-------', values);
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Technology" />
      <ScrollView>
        <View style={styles.container}>
          <Formik
            validationSchema={loginValidationSchema}
            initialValues={{technology: data.technology, url: data.url}}
            enableReinitialize = {true}
          onSubmit={values => {
            handleSubmit(values);
          }}>
            {({handleChange, handleBlur, handleSubmit, errors, touched,values}) => (
              <>
                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="Name*"
                    value={values.technology}
                    style={styles.textInput}
                    onChangeText={handleChange('technology')}
                    onBlur={handleBlur('technology')}
                  />
                </View>
                {errors.technology && touched.technology && (
                  <Text style={styles.errorStyle}>
                    {errors.technology}
                  </Text>
                )}

                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="URL"
                    value={values.url}
                    style={styles.textInput}
                    onChangeText={handleChange('url')}
                    onBlur={handleBlur('url')}
                  />
                </View>
                {errors.url && touched.url && (
                  <Text style={styles.errorStyle}>{errors.url}</Text>
                )}
                <TouchableOpacity
                  style={styles.submitBtn}
                 onPress={() => {
                    handleSubmit();
                  }}>  
                      <Text style={styles.submitText}>Submit</Text>
                </TouchableOpacity>
              </>
            )}
          </Formik>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  margin: 15,
  borderRadius: 10,
  padding:4,
  backgroundColor: COLORS.pureWhite,
  },
  innerBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    padding:2,
    backgroundColor: COLORS.lightBlue,
  },
  textInput: {
    marginStart: '3%',
    fontSize: 15,
    flex: 1,
  },
  iconStyle: {
    padding: '3%',
    margin: '1%',
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  errorStyle:{
    ...FONTS.appFontSemiBold,color:COLORS.red,textAlign:'center'
  },
  submitBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginTop: 20,
    marginHorizontal: 22,
    padding: '4%',
    backgroundColor: COLORS.blue,
  },
  submitText: {
    color: COLORS.white,
    ...FONTS.appFontSemiBold,
  },
})
export default EditTechnology;