import React, {useState,useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
const AddProjectTarget = () => {
  const [id, setId] = useState();
  const [newData, setNewData] = useState([]);
  const [startDate, setStartDate] = useState('');

  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
        'http://newresourcing.nimapinfotech.com/api/project-target',
        requestOptions,
      );

      // console.log(data.data.data.projectTarget);

      setNewData(data.data.data.projectTarget);
    } catch (error) {
      console.log(error);
    }
  };
  const postUser = async () => {
    const store = {
      "resource":id,
      "date":startDate

    }
    console.log('check------------->>>>',store);

    try {
      
      const token = await AsyncStorage.getItem('token');
  
      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
  
      const {data} = await axios.post(
       'http://newresourcing.nimapinfotech.com/api/project-target',
        store,
        requestOptions,
      );
  
      console.log('check-------------->', data)
    } catch (err) {
      console.log("Error--------------------------->",err);
    }
  };
  // const handleSubmit = values => {
  //   postUser(values);
  // };
  const clientsOptions = newData.filter(t => t.resources !== null);
  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Project Target" />
        <View style={styles.TextInputView}>          
          <Picker
            selectedValue={id}
            style={styles.TextInput}
            onValueChange={(value)=> setId (value)}
            mode='dropdown'>
              
               <Picker.Item label="Select Resource" value="" /> 
            {clientsOptions.map((item, index) => (
              <Picker.Item
                key={item.resources.id}
                label={item.resources.fname}
                value={item.resources.id}
              />
            ))}
          </Picker>
        </View>
        <View style={styles.textInputDate}>
        <DatePicker
          style={styles.TextInput}
          date={startDate} 
          value={startDate}
          mode="date" 
          placeholder="Start Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel" 
          showIcon={false}
          customStyles={{dateInput:{borderWidth:0}}}         
          onDateChange={startDate => {
            setStartDate(startDate);
          }}
        

        />
      <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />

      </View>


      <TouchableOpacity style={styles.buttonStyle}
              onPress={()=> postUser()}>
        <Text style={styles.textStyle}>Submit</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },

  TextInputView: {
    flexDirection: 'row',
    margin: 15,
    marginTop: '5%',
    // padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  TextInput: {
    marginStart: '3%',
    fontSize: 15,
    flex: 1,
    
  },
  IconStyle: {
    padding: '3%',
    margin: '1%',
  },

  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    width: '100%',
    padding: 6,
    backgroundColor: COLORS.pureWhite,
  },
  buttonStyle: {
    backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
    // position: 'absolute',
    // bottom:0,
    // left:0,
  },
  textStyle: {
    alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
  },
  
 textInputDate:{
  flexDirection: 'row',
  justifyContent: 'space-between',
  margin: 15,
  borderRadius: 10,
  padding:8,
  backgroundColor: COLORS.pureWhite
  },
  iconStyle:{
    margin:10
  }
});

export default AddProjectTarget;