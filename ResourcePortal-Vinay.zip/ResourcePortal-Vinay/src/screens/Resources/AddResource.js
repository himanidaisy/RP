import React, {useState,useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  TouchableOpacity,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import DatePicker from 'react-native-datepicker';
import {COLORS} from '../../constants/theme';
import EmailIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const AddResource = () => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [id, setId] = useState('Select External Resource')
  const [fname, setFname] = useState('');
  const [lname, setLname] = useState('');
  const [phone, setPhone] = useState('');
  const [exp, setExp] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail] = useState('');
  const [no, setNo] = useState('');
  const [language, setLanguage] = useState('Select Language');
  const [otherlanguage, setOtherLanguage] = useState('');
  const [resume, setResume] = useState('');
  // const [resumet, setResumet] = useState('');
  const [contractf, setContractf] = useState('');
  // const [contractft, setContractft] = useState('');
  // const [ends, setEnds] = useState('');
  // const [bench, setBench] = useState('');
  // const [checklist, setChecklist] = useState('');
  // const [passing, setPassing] = useState('');
  // const [Other, setOther] = useState('');
  // const [personal, setPersonal] = useState('');
  // const [project, setProject] = useState('');
  // const [pan, setPan] = useState('');
  // const [pf, setPf] = useState('');
  // const [flag, setFlag] = useState('');
  const [newData, setNewData] = useState([]);
  useEffect(() => {
    getResource();
    
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
        'http://newresourcing.nimapinfotech.com/api/resource',
        requestOptions,
      );

      console.log(data.data.data.resources);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);

    }
  };
  const postUser = async () => {
    const store = 
      {
    "company_name": id,
     "fname": fname,
     "lname": language,
     "phone": phone,    
     "exp_date": exp,
     "resident_address": address,
     "email": email,
     "refer_no": no,
     "technology": language,
     "otherlanguage": otherlanguage,
     "resume": resume,
    //  "resume_type":resumet,
     "contract_file": contractf,
    //  "contract_file_type": contractft,
    //  "contract_start_date": startDate,
    //  "contract_end_date":endDate,
    //  "end_date": ends,
    //  "on_bench": bench,
    //  "checklist": checklist,
    //  "passing_year": passing,
    //  "other_docs": Other,
    //  "personal_email": personal,
    //  "project": project,
    //  "pan_link": pan,
    //  "pf_opt_out_form_link": pf,
    //  "flag":flag
   }
  
    console.log('valu--------', store)
  
    try {
      const token = await AsyncStorage.getItem('token');
  
      const requestOptions = {
        
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
  
      const {data} = await axios.post(
       'http://newresourcing.nimapinfotech.com/api/resource',
        
        requestOptions,
        
      );
      console.log('check-------------->', data)
  
    } catch (err) {
      console.log("Error--------------------------->",err);
    }
  };
  const clientsOptions = newData.filter(t=>t.vendor !== null)
  const languageOptions = newData.filter(t=>t.languages !== null)
  const experienceOptions = newData.filter(t=>t.exp_date !== null)


  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Resource" />
      <ScrollView style={styles.containerView}>
      <View style={styles.pickerSTyle}>
        <Picker
        selectedValue={id}
        style={styles.TextInput}
        onValueChange={(value)=> setId (value)}>
          <Picker.Item label="Vendor List" value="" /> 

          {clientsOptions.map((item,index)=>(
             <Picker.Item key={item.vendor.id}  label={item.vendor.company_name} value={item.vendor.id} />
          ))
          }
      </Picker>
    </View>

        <View style={styles.TextInputView}>
          <TextInput placeholder="First Name*" style={styles.TextInput} 
           value={fname}
           onChangeText={(data)=> setFname(data)}/>
        </View>

        <View style={styles.TextInputView}>
          <TextInput placeholder="Last Name*" style={styles.TextInput} 
          value={lname}
          onChangeText={(data)=> setLname(data)}/>
        </View>

        <View style={styles.TextInputView}>
          <View style={styles.innerBtn}>
            <FontAwesome name="phone" size={25} style={styles.iconStyleView} />
          </View>
          <TextInput placeholder="Phone Number*" style={styles.TextInput} 
          value={phone}
          onChangeText={(data)=> setPhone(data)}/>
        </View>

        <View style={styles.TextInputView}>
          <View style={styles.innerBtn}>
            <EmailIcon
              name="email-outline"
              size={20}
              style={styles.iconStyleView}
            />
          </View>
          <TextInput placeholder="Email Id*" style={styles.TextInput} 
          value={email}
          onChangeText={(data)=> setEmail(data)}/>
        </View>

        <View style={styles.TextInputView}>
          <TextInput placeholder="Reference Number" style={styles.TextInput} 
          value={no}
          onChangeText={(data)=> setNo(data)}/>
        </View>

        <View style={styles.pickerSTyle}>
        <Picker
        selectedValue={language}
        style={styles.TextInput}
        onValueChange={(value)=> setLanguage (value)}>
                    <Picker.Item label="Select Language" value="" /> 

          {languageOptions.map((item,index)=>(
             <Picker.Item key={item?.languages[0].id}  label={item?.languages[0].technology} value={item?.languages[0].id} />
          ))
          }
      </Picker>
    </View>

        <View style={styles.TextInputView}>
          <TextInput placeholder="Other Languages" style={styles.TextInput}
          value={otherlanguage}
          onChangeText={(data)=> setOtherLanguage(data)}/>
        </View>

        <View style={styles.pickerSTyle}>
        <Picker
        selectedValue={exp}
        style={styles.TextInput}
        onValueChange={(value)=> setExp (value)}>
                    <Picker.Item label="Select Experience Year" value="" /> 

          {experienceOptions.map((item,index)=>(
             <Picker.Item key={item.exp_date.id}  label={item.exp_date} value={item.exp_date.id} />
          ))
          }
      </Picker>
    </View>

        <View style={styles.TextInputView}>
          <TextInput
            placeholder=" Residential Address"
            style={styles.TextInput}
            value={address}
           onChangeText={(data)=> setAddress(data)}/>
          
        </View>

        <View style={styles.TextInputView}>
          <TextInput
            placeholder="Upload Resume"
            style={styles.TextInput}
            value={resume}
           onChangeText={(data)=> setResume(data)}/>
          
        </View>
        <View style={styles.textInputDate}>
        <DatePicker
          style={styles.TextInput}
          date={startDate} 
          value={startDate}
          mode="date" 
          placeholder="Contract Start Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"   
          showIcon={false}
      customStyles={{dateInput:{borderWidth:0}}}       
          onDateChange={startDate => {
            setStartDate(startDate);
          }}
        

        />
       <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />

      </View>
     
      <View style={styles.textInputDate}>
        <DatePicker
          style={styles.TextInput}
          date={endDate}
          value={endDate}
          mode="date" 
          placeholder="Contract End Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          showIcon={false}
      customStyles={{dateInput:{borderWidth:0}}}
          onDateChange={endDate => {
            setEndDate(endDate);
          }}
        />
         <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />
  </View>
       

  <View style={styles.TextInputView}>
          <TextInput
            placeholder=" Upload Contract"
            style={styles.TextInput}
            value={contractf}
            onChangeText={(data)=> setContractf(data)}/>
        </View>

        <TouchableOpacity style={styles.submitBtn} onPress={postUser}>
          <Text style={styles.submitText}>Submit</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    // flexDirection: 'column',
    backgroundColor: COLORS.white,
  },
  containerView: {
    marginHorizontal: '3%',
    marginVertical: '3%',
  },
  TextInputView: {
    flexDirection: 'row',
    margin: 15,
    marginTop: '5%',
    padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  
  },
  pickerSTyle:{
    flexDirection: 'row',
    margin: 15,
    marginTop: '5%',
    // padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  TextInput: {
    flex: 1,
    marginStart: '3%',
    fontSize: 15,
  },

  iconStyle: {
    padding: 10,
    margin: 2,
  },
  iconStyleView:{
    padding: '3%',
    margin: '1%',
  },
  uploadBtn: {
    // flex:1,
    flexDirection: 'row',
    justifyContent: 'center',
    // justifyContent:'space-between',
    alignItems: 'center',
    margin: '3%',
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  innerBtn: {
    // flex:1,
    flexDirection: 'row',
    justifyContent: 'center',
    // justifyContent:'space-between',
    alignItems: 'center',
    // margin: '3%',
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  btnText: {
    // flex:1,
    // marginStart:'3%',
    fontSize: 15,
  },
  selectorView: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    margin: '3%',
    alignItems: 'center',
  },

  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    width: '100%',
    paddingHorizontal: 20,
    backgroundColor: COLORS.pureWhite,
    margin: 5,
  },
  iconStyle: {
    margin: 10,
  },
  submitBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginTop: 40,
    marginHorizontal: 8,
    padding: 18,
    backgroundColor: COLORS.blue,
  },
  submitText: {
    color: COLORS.white,
    fontSize: 15,
  },
  textInputDate:{
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 15,
    borderRadius: 10,
    padding:8,
    backgroundColor: COLORS.pureWhite
    },
  
});

export default AddResource;
