import React, {useState,useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,GLOBALSTYLES} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome'
const EditPurchaseOrder = ({route,navigation}) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [select, setSelect] = useState();
  const [order, setOrder] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [pdf, setPdf] = useState('');
  const [data, setData] = useState({});
  const [name, setName] = useState('');

  console.log('valuess', route.params.newData.id);
  useEffect(() => {
    setData(route.params.newData);
    setName(route.params.newData);

  }, []);


 //put
  const putUser = async values => {
    console.log(values);
    const id = route.params.newData.id;
    const store = {
        "client_id": select,
        "order_number": order,
        "start_date": startDate,
        "end_date": endDate,
        "title":title ,
        "description": description,
        "pdf_file": pdf
      }
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        `http://newresourcing.nimapinfotech.com/api/purchase/${id}`,
        store,
        requestOptions,
      );
       console.log(data);
      setData(route.params.newData);
      setName(route.params.newData);

      if (data.status) {
        ToastAndroid.showWithGravity(
          ' Purchase Edited Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
    navigation.goBack()
      }
    } catch (err) {
      ToastAndroid.showWithGravity(
        'Purchase not Edited',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    putUser(values);
    // console.log('values------->', values);
  };
  const clientsOptions = newData.filter(t=>t.clients !== null)

  
    
  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Purchase Order" />
      <ScrollView style={styles.containerView}>
     
      <View style={styles.pickerStyle}>
        <Picker
        selectedValue={data.select}
        style={styles.TextInputViews}
        onValueChange={(value)=> setSelect (value)}
        mode='dropdown'
        >
          <Picker.Item label="Select Client" value="" /> 
          {clientsOptions.map((item,index)=>(
             <Picker.Item key={item.clients.id} 
              label={item.clients.client_name}
               value={item.clients.id} /> 
          ))
          }
      </Picker>
    </View>
   
  <View style={styles.TextInputView}>
          <TextInput
            placeholder="Purchase Order Number*"
            style={styles.TextInputViews}
       value={data.order}
       onChangeText={(data)=> setOrder(data)}
          />
        </View>
      

        <View style={styles.TextInputView}>
        <DatePicker
          style={styles.dateTextStyle}
          date={startDate} 
          value={data.startDate}
          mode="date" 
          placeholder="Start Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"          
          onDateChange={startDate => {
            setStartDate(startDate);
          }}
        

        />
        {/* <Icon name="calendar-o" size={15} style={styles.IconStyle} /> */}

      </View>
     
      <View style={styles.TextInputView}>
        <DatePicker
          style={styles.TextInputViews}
          date={endDate}
          value={data.endDate}
          mode="date" 
          placeholder="End Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          onDateChange={endDate => {
            setEndDate(endDate);
          }}
        />
        {/* <Icon name="calendar-o" size={15} style={styles.IconStyle} /> */}
  </View>

     <View style={styles.TextInputView}>

          <TextInput placeholder="Title" style={styles.TextInputViews} 
          value={data.title}
            onChangeText={(data)=> setTitle(data)}
          />
        </View>
       

        <View style={styles.TextInputView}>
          <TextInput placeholder="Description" style={styles.TextInputViews}
          value={data.description}
          onChangeText={(data)=> setDescription(data)}
          />
        </View>
     
        
        <View style={styles.TextInputView}>
          <TextInput placeholder="Upload" style={styles.TextInputViews}
            value={data.pdf}
           onChangeText={(data)=> setPdf(data)}
            
          />
        </View>
      
        <TouchableOpacity style={styles.submitBtn}
        onPress={() => {handleSubmit()}}> 
          <Text style={styles.submitText}>Submit</Text>
        </TouchableOpacity>

     
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
 
  TextInputView: {
  flexDirection: 'row',
    margin: 15,
    marginTop: '5%',
    padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  pickerStyle:{
  flexDirection: 'row',
  margin: 15,
  marginTop: '5%',
  // padding: '1%',
  borderRadius: 10,
  backgroundColor: COLORS.pureWhite,
  },
  TextInputViews: {
    flex: 1,
    marginStart: '3%',
    fontSize: 15,
  },

  IconStyle: {
    padding: 10,
    margin: 2,
  },
  uploadBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    margin: '3%',
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  innerBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  btnText: {
    fontSize: 15,
  },
  selectorView: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    margin: '3%',
    alignItems: 'center',
  },

  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    width: '100%',
    paddingHorizontal: 20,
    backgroundColor: COLORS.pureWhite,
    margin: 5,
  },
  IconStyle: {
    padding: 10,
    margin: 5,
  },
  submitBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginTop: 40,
    marginHorizontal: 12,
    padding: 18,
    margin:10,
    backgroundColor: COLORS.blue,
  },
  submitText: {
    color: COLORS.white,
    fontSize: 15,
  },
  dateTextStyle:{

    flex: 1,
    marginStart: '3%',
    fontSize: 15,
    borderColor:COLORS.pureWhite
  }
});

export default EditPurchaseOrder;

