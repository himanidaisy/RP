import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  FlatList,
  Text,
  TouchableOpacity,
  View,
Modal,ActivityIndicator
} from 'react-native';
import SearchBox from '../../components/SearchBox';
import {COLORS, GLOBALSTYLES} from '../../constants/theme';

import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {URL} from '../../constants/configure';

const PurchaseOrderMaster = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding]);

  //get


  const getResource = async () => {

    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.PURCHASEORDERMASTERGET_URL,
        requestOptions,
      );

      // console.log(data.data.data.purchase);
      setNewData(data.data.data.purchase);
      setLoding(false);

    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };
  
  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.title.toLowerCase().includes(search.toLowerCase()) ||
          data.clients.client_name.charAts().includes(search.charAts()) 
        ) {
          console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };


  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
       <ActivityIndicator animating={true} size="large" style={{opacity:1,position: 'absolute',
       left: 0,
       right: 0,
       top: 0,
       bottom: 0,
       alignItems: 'center',
       justifyContent: 'center'}}  />  
      ) : (
        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
            <View style={GLOBALSTYLES.lebalView}>
              <Text style={GLOBALSTYLES.lebal}>Client Name</Text>
              <View style={GLOBALSTYLES.contentView}>
                <Text style={GLOBALSTYLES.content}>
                  {item.clients === null ? '-' : item?.clients.client_name}
                </Text>
              </View>
            </View>
            <View style={GLOBALSTYLES.lebalView}>
              <Text style={GLOBALSTYLES.lebal}>Title</Text>
              <View style={GLOBALSTYLES.contentView}>
                <Text style={GLOBALSTYLES.content}>
                  {item.title === null ? '-' : item.title}
                </Text>
              </View>
            </View>
            <View style={GLOBALSTYLES.lebalView}>
              <Text style={GLOBALSTYLES.lebal}>Description</Text>
              <View style={GLOBALSTYLES.contentView}>
                <Text style={GLOBALSTYLES.content}>
                  {item.description === null ? '-' : item.description}
                </Text>
              </View>
            </View>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Order Number</Text>

                <Text style={GLOBALSTYLES.content}>
                {item.order_number === null ? '-' : item.order_number}
                </Text>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>PDF</Text>
                <View style={GLOBALSTYLES.viewContainerView}>
                      <Modal
                        animationType='none'
                        transparent={true}
                        visible={modalVisible}
                        onRequestClose={() => {
                          Alert.alert('modal closed');
                          setModalVisible(!modalVisible);
                        }}>
                        <View styte={GLOBALSTYLES.viewContainerView}>
                          <View style={GLOBALSTYLES.modalView}>
                            <Text style={GLOBALSTYLES.pdflinkText}>
                              { item.pdf_file === null ? '-' :item.pdf_file}
                            </Text>

                            <TouchableOpacity
                              onPress={() => setModalVisible(!modalVisible)}>
                              <Text style={GLOBALSTYLES.closeButton}>Close</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      </Modal>
                      <TouchableOpacity
                        onPress={() => setModalVisible(!modalVisible)}>
                        <Text style={GLOBALSTYLES.viewButton}>View</Text>
                      </TouchableOpacity>
                    </View>
              </View>
            </View>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Start Date</Text>

                <Text style={GLOBALSTYLES.content}>
                {item.start_date === null ? '-' : item.start_date}
                </Text>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>End Date</Text>
                <Text style={GLOBALSTYLES.content}>
                  {item.end_date === null ? '-' : item.end_date}
                </Text>
              </View>
            </View>
           

            <TouchableOpacity onPress={()=> navigation.navigate('Edit Purchase Order', {newData: item})}

                  style={{
                    backgroundColor: COLORS.blue,
                    margin: 5,
                    borderRadius: 10,
                    padding: 15,
                  }}>
                  <Text style={{color: COLORS.pureWhite, textAlign: 'center'}}>
                    Edit
                  </Text>
                </TouchableOpacity>
          </View>
        )}
      />
      )}
    </SafeAreaView>
  );
};

export default PurchaseOrderMaster;
