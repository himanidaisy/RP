import React, {useState,useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,GLOBALSTYLES} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
const AddPurchaseOrder = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [id, setId] = useState('');
  const [order, setOrder] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [pdf, setPdf] = useState('');

  useEffect(() => {
    getResource();
    
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
        URL.PURCHASEORDERMASTERGET_URL,
        requestOptions,
      );

      console.log(data.data.data.purchase);

      setNewData(data.data.data.purchase);
      if (data.status === 201) {
        ToastAndroid.showWithGravity(
          'Purchase Order Added Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
        navigation.navigate('Purchase Order Master');
      }
    } catch (err) {
      ToastAndroid.showWithGravity(
        'Purchase Order not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    
    } 
  };

const postUser = async () => {
  const store = {
  "client_id": id,
  "order_number": order,
  "start_date": startDate,
  "end_date": endDate,
  "title":title ,
  "description": description,
  "pdf_file": pdf
}
  console.log('valu--------', store)

  try {
    const token = await AsyncStorage.getItem('token');

    const requestOptions = {
      
      method: 'POST',
      Accept: 'application/json',
      'Content-Type': 'application/json',
      headers: {Authorization: 'Bearer ' + token},
    };

    const {data} = await axios.post(
     'http://newresourcing.nimapinfotech.com/api/purchase',store,
      
      requestOptions,
      
    );
    console.log('check-------------->', data)
    if (data.message) {
        ToastAndroid.showWithGravity(
          'Purchase order created successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
        navigation.navigate('Purchase Order Master');
      }
  } catch (err) {
    console.log(err.response)
    ToastAndroid.showWithGravity(
      'Purchase order not created',
      ToastAndroid.SHORT,
      ToastAndroid.BOTTOM,
    );
  }

};


  const clientsOptions = newData.filter(t=>t.clients !== null)

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Purchase Order" />
      <ScrollView style={styles.containerView}>
     
      <View style={styles.pickerStyle}>
        <Picker
        selectedValue={id}
        style={styles.TextInputViews}
        onValueChange={(value)=> setId (value)}
        mode='dropdown'
        >
          <Picker.Item label="Select Client" value="" /> 
          {clientsOptions.map((item,index)=>(
             <Picker.Item key={item.clients.id} 
              label={item.clients.client_name}
               value={item.clients.id} /> 
          ))
          }
      </Picker>
    </View>
   
  <View style={styles.TextInputView}>
          <TextInput
            placeholder="Purchase Order Number*"
            style={styles.TextInputViews}
       value={order}
       onChangeText={(data)=> setOrder(data)}
          />
        </View>
      

        <View style={styles.TextInputView}>
        <DatePicker
          style={styles.dateTextStyle}
          date={startDate} 
          value={startDate}
          mode="date" 
          placeholder="Start Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel" 
          showIcon={false}
          customStyles={{dateInput:{borderWidth:0}}}         
          onDateChange={startDate => {
            setStartDate(startDate);
          }}
        

        />
       <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />

      </View>
     
      <View style={styles.textInputDate}>
        <DatePicker
          style={styles.dateTextStyle}
          date={endDate}
          value={endDate}
          mode="date" 
          placeholder="End Date"
          format="YYYY-MM-DD"
          minDate="2015-01-01"
          maxDate="2023-01-01"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          showIcon={false}
          customStyles={{dateInput:{borderWidth:0}}}  
          onDateChange={endDate => {
            setEndDate(endDate);
          }}
        />
      <FontAwesome name="calendar-o" size={20} style={styles.iconStyle} />

  </View>

     <View style={styles.TextInputView}>

          <TextInput placeholder="Title" style={styles.TextInputViews} 
          value={title}
            onChangeText={(data)=> setTitle(data)}
          />
        </View>
       

        <View style={styles.TextInputView}>
          <TextInput placeholder="Description" style={styles.TextInputViews}
          value={description}
          onChangeText={(data)=> setDescription(data)}
          />
        </View>
     
        
        <View style={styles.TextInputView}>
          <TextInput placeholder="Upload" style={styles.TextInputViews}
            value={pdf}
           onChangeText={(data)=> setPdf(data)}
            
          />
        </View>
      
        <TouchableOpacity style={styles.submitBtn}
        onPress={()=> postUser()}>
          <Text style={styles.submitText}>Submit</Text>
        </TouchableOpacity>

     
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
 
  TextInputView: {
  flexDirection: 'row',
    margin: 15,
    marginTop: '5%',
    padding: '1%',
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  pickerStyle:{
  flexDirection: 'row',
  margin: 15,
  marginTop: '5%',
  // padding: '1%',
  borderRadius: 10,
  backgroundColor: COLORS.pureWhite,
  },
  TextInputViews: {
    flex: 1,
    marginStart: '3%',
    fontSize: 15,
  },

  IconStyle: {
    padding: 10,
    margin: 2,
  },
  uploadBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    margin: '3%',
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  innerBtn: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    backgroundColor: COLORS.lightBlue,
  },
  btnText: {
    fontSize: 15,
  },
  selectorView: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    margin: '3%',
    alignItems: 'center',
  },

  selectButton: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderRadius: 10,
    width: '100%',
    paddingHorizontal: 20,
    backgroundColor: COLORS.pureWhite,
    margin: 5,
  },
  iconStyle: {
    margin:10
  },
  submitBtn: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    paddingHorizontal: 20,
    marginTop: 40,
    marginHorizontal: 12,
    padding: 18,
    margin:10,
    backgroundColor: COLORS.blue,
  },
  submitText: {
    color: COLORS.white,
    fontSize: 15,
  },
  dateTextStyle:{
    flex: 1,
    marginStart: '3%',
    fontSize: 15,
  },
  textInputDate:{
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 15,
    borderRadius: 10,
    padding:8,
    backgroundColor: COLORS.pureWhite
    },
});

export default AddPurchaseOrder;

