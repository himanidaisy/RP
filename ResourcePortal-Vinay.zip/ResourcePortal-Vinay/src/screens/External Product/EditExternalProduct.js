import React, {useState,useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  StyleSheet
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,FONTS} from '../../constants/theme';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';

const EditExternalProduct = ({route,navigation}) => {
    const [data, setData] = useState({});
    const [name, setName] = useState('');
    console.log('valuess', route.params.newData.id);
    useEffect(() => {
      setData(route.params.newData);
      setName(route.params.newData);
    }, []);

  const loginValidationSchema = yup.object().shape({
    name: yup.string().required('Please fill out this filed'),
    url: yup.string().required('Please fill out this filed'),
    description: yup.string().required('Please fill out this filed'),
  });
//put
const putUser = async values => {
    // console.log(values);
    const id = route.params.newData.id;
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        `http://newresourcing.nimapinfotech.com/api/external-products/${id}`,
        values,
        requestOptions,
      );
       // console.log(data);
      setData(route.params.newData);
      setName(route.params.newData);

      if (data.status) {
        ToastAndroid.showWithGravity(
          'External Product Edited Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
    navigation.goBack()
      }
    } catch (err) {
      ToastAndroid.showWithGravity(
        'externalProduct not Edited',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    putUser(values);
    // console.log('values------->', values);
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit External Project" />
      <ScrollView>
        <View style={styles.container}>
          <Formik
            validationSchema={loginValidationSchema}
            initialValues={{name: data.name, url: data.url, description:data.description}}
            enableReinitialize = {true}
            onSubmit={values => {
              handleSubmit(values);
            }}>
            {({handleChange, handleBlur, handleSubmit, errors, touched,values}) => (
              <>
                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="Name*"
                    value={values.name}
                    style={styles.textInput}
                    onChangeText={handleChange('name')}
                    onBlur={handleBlur('name')}
                  />
                </View>
                {errors.name && touched.name && (
                  <Text style={styles.errorStyle}>{errors.name}</Text>
                )}

                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="URL"
                    value={values.url}
                    style={styles.textInput}
                    onChangeText={handleChange('url')}
                    onBlur={handleBlur('url')}
                  />
                </View>
                {errors.url && touched.url && (
                  <Text style={styles.errorStyle}>{errors.url}</Text>
                )}

                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="Description"
                    value={values.description}
                    style={styles.textInput}
                    onChangeText={handleChange('description')}
                    onBlur={handleBlur('description')}
                  />
                </View>
                {errors.description && touched.description && (
                  <Text style={styles.errorStyle}>
                    {errors.description}
                  </Text>
                )}

                <TouchableOpacity
                  style={styles.submitBtn}
                  onPress={() => {handleSubmit()}}>  
                  <Text style={styles.submitText}>Submit</Text>
                </TouchableOpacity>
              </>
            )}
          </Formik>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 15,
    borderRadius: 10,
    padding:4,
    backgroundColor: COLORS.pureWhite,
    },
    innerBtn: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 10,
      padding:2,
      backgroundColor: COLORS.lightBlue,
    },
    textInput: {
      marginStart: '3%',
      fontSize: 15,
      flex: 1,
    },
    iconStyle: {
      padding: '3%',
      margin: '1%',
    },
    submitBtn: {
      backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
    },
    submitText: {
      alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    },
    errorStyle:{
      ...FONTS.appFontSemiBold,color:COLORS.red,textAlign:'center'
    }
  })
export default EditExternalProduct;
