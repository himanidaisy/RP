import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  StyleSheet
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS,FONTS} from '../../constants/theme';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';

const AddExternalProduct = ({navigation}) => {
  const postUser = async values => {
    // console.log('check--------------',values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.EXTERNALPRODUCTPOST_URL,
        values,
        requestOptions,
      );

      // console.log(data);
      
      if (data.status) {
        ToastAndroid.showWithGravity(
          'External Product Added Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
    navigation.goBack()
      }
    } catch (err) {
      ToastAndroid.showWithGravity(
        'externalProduct not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );

    }
  };
  const handleSubmit = values => {
    postUser(values);
  };

  const loginValidationSchema = yup.object().shape({
    name: yup.string().required('Please fill out this filed'),
    url: yup.string().required('Please fill out this filed'),
    description: yup.string().required('Please fill out this filed'),
  });
  // navigation = useNavigation();

  return (
    <SafeAreaView style={styles.mainContainer}>
      <CustomNavigationBar back={true} headername="Add External Product" />
      <ScrollView>
        <View style={styles.container}>
          <Formik
            validationSchema={loginValidationSchema}
            initialValues={{name: '', url: '', description: ''}}
            onSubmit={handleSubmit}>
            {({handleChange, handleBlur, handleSubmit, errors, touched}) => (
              <>
                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="Name*"
                    style={styles.textInput}
                    onChangeText={handleChange('name')}
                    onBlur={handleBlur('name')}
                  />
                </View>
                {errors.name && touched.name && (
                  <Text style={styles.errorStyle}>{errors.name}</Text>
                )}

                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="URL"
                    style={styles.textInput}
                    onChangeText={handleChange('url')}
                    onBlur={handleBlur('url')}
                  />
                </View>
                {errors.url && touched.url && (
                  <Text style={styles.errorStyle}>{errors.url}</Text>
                )}

                <View style={styles.textInputView}>
                  <TextInput
                    placeholder="Description"
                    style={styles.textInput}
                    onChangeText={handleChange('description')}
                    onBlur={handleBlur('description')}
                  />
                </View>
                {errors.description && touched.description && (
                  <Text style={styles.errorStyle}>
                    {errors.description}
                  </Text>
                )}

                <TouchableOpacity
                  style={styles.submitBtn}
                  onPress={handleSubmit}>
                  <Text style={styles.submitText}>Submit</Text>
                </TouchableOpacity>
              </>
            )}
          </Formik>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
  textInputView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 15,
    borderRadius: 10,
    padding:4,
    backgroundColor: COLORS.pureWhite,
    },
    innerBtn: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 10,
      padding:2,
      backgroundColor: COLORS.lightBlue,
    },
    textInput: {
      marginStart: '3%',
      fontSize: 15,
      flex: 1,
    },
    iconStyle: {
      padding: '3%',
      margin: '1%',
    },
    submitBtn: {
      backgroundColor: COLORS.blue,
    padding: '3%',
    width: '90%',
    borderRadius: 10,
    marginTop: '5%',
    marginStart: '5%',
    },
    submitText: {
      alignSelf: 'center',
    ...FONTS.appFontSemiBold,
    marginVertical: '2%',
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    },
    errorStyle:{
      ...FONTS.appFontSemiBold,color:COLORS.red,textAlign:'center'
    }
  })
export default AddExternalProduct;
