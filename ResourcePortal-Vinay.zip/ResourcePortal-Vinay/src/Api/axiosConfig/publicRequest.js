import axios from "axios";

export  const publicRequest = axios.create({
    baseURL: 'http://newresourcing.nimapinfotech.com/api'
})