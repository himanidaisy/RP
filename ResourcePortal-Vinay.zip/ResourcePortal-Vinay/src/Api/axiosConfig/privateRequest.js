import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const privateRequest = axios.create({
    baseURL: 'http://newresourcing.nimapinfotech.com/api'
})

const getToken = () => {
    if(AsyncStorage.getItem('authUser') !== null){
        return JSON.parse(AsyncStorage.getItem('authUser')).token
    }
}
privateRequest.interceptors.request.use((request) => {
    request.headers.common.Authorization = `Bearer ${getToken()}`;
    return request;
})