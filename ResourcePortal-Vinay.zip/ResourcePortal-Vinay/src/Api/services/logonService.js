import {publicRequest} from '../axiosConfig/publicRequest';

export const loginUser = (user) => {
    return publicRequest.post('/auth/signIn', user).then(res => res.data)
}