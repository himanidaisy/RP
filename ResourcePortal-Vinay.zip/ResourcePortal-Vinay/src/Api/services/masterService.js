import {privateRequest} from '../axiosConfig/privateRequest';

export const fetchTechnologyMaster =() => {
    return privateRequest.get('/technology').then(res=>res.data)
}